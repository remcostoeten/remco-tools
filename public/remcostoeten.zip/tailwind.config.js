/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        black: "#000",
        white: "#fff",
        gainsboro: "#e8e7ea",
        gray: {
          "100": "#939395",
          "200": "#909090",
        },
        skyblue: "#93c6e7",
        lightblue: "#aee2ff",
        thistle: "#fedeff",
        blueviolet: "#9747ff",
      },
      fontFamily: {
        inter: "Inter",
      },
      borderRadius: {
        "10xl-5": "29.5px",
        xl: "20px",
      },
    },
    fontSize: {
      base: "16px",
      "105xl": "124px",
      "5xl": "24px",
      xl: "20px",
      "4xl": "23px",
      xs: "12px",
      "11xl": "30px",
      "61xl": "80px",
      "13xl": "32px",
      mid: "17px",
      inherit: "inherit",
    },
  },
  corePlugins: {
    preflight: false,
  },
};
