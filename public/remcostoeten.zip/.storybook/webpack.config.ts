module.exports = {
  module: {
    rules: [
      {
        test: /.css$/,
        use: [
          "style-loader",
          {
            loader: "css-loader",
            options: {
              // Customize css-loader options here
              url: true, // Disable handling of url() functions
            },
          },
          // Other loaders as needed
        ],
      },
    ],
  },
};
