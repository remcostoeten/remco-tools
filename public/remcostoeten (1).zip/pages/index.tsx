import type { NextPage } from "next";
import FrameComponent from "../components/frame-component";
import Property1Default from "../components/property1-default";
import Intro from "../components/intro";
import Socials from "../components/socials";
import Blocks from "../components/blocks";
import Footer from "../components/footer";

const Home: NextPage = () => {
  return (
    <div className="relative bg-white w-full h-[8855px] overflow-hidden text-left text-5xl text-black font-inter">
      <div className="absolute top-[7467.5px] left-[-0.5px] box-border w-[1441px] h-px border-t-[1px] border-solid border-gainsboro" />
      <div className="absolute top-[7588.5px] left-[-0.5px] box-border w-[1441px] h-px border-t-[1px] border-solid border-gainsboro" />
      <div className="absolute top-[8514.5px] left-[-0.5px] box-border w-[1441px] h-px border-t-[1px] border-solid border-gainsboro" />
      <div className="absolute top-[8788.5px] left-[-0.5px] box-border w-[1441px] h-px border-t-[1px] border-solid border-gainsboro" />
      <FrameComponent
        sectionTitle="Contact us"
        frameDivBorder="2px solid #9747ff"
        frameDivPosition="absolute"
        frameDivTop="8288px"
        frameDivLeft="628px"
        meetTheTeamColor="#9747ff"
      />
      <Property1Default
        property1DefaultPosition="absolute"
        property1DefaultTop="1802px"
        property1DefaultLeft="0px"
      />
      <div className="absolute top-[50px] left-[70px] w-[1300px] h-9 overflow-hidden text-mid">
        <div className="absolute top-[0px] left-[873px] font-medium">Home</div>
        <div className="absolute top-[0px] left-[965px] font-medium">About</div>
        <div className="absolute top-[0px] left-[1059px] font-medium">Work</div>
        <div className="absolute top-[0px] left-[1145px] font-medium">News</div>
        <div className="absolute top-[0px] left-[1235px] font-medium">
          Contact
        </div>
        <b className="absolute top-[0px] left-[0px] text-11xl">MK</b>
        <div className="absolute top-[3px] left-[59px] text-xs font-medium text-gray-100">
          <p className="m-0">{`UI/UX Designer &`}</p>
          <p className="m-0">Product Designer</p>
        </div>
      </div>
      <Intro />
      <Socials />
      <div className="absolute top-[1078px] left-[70px] w-[1300px] h-[474px] overflow-hidden text-13xl">
        <b className="absolute top-[0px] left-[0px] leading-[140.52%] inline-block w-[607px]">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. `}</b>
        <b className="absolute top-[140px] left-[0px] leading-[140.52%] inline-block w-[607px]">
          Lorem Ipsum has been the industry's standard dummy text ever since the
          1500s, when an unknown printer took a galley of type and scrambled it
          to make a type specimen book.
        </b>
        <FrameComponent
          sectionTitle="Meet the team"
          frameDivBorder="2px solid #9747ff"
          frameDivPosition="absolute"
          frameDivTop="416px"
          frameDivLeft="3px"
          meetTheTeamColor="#9747ff"
        />
        <div className="absolute top-[0px] left-[770px] bg-thistle w-[530px] h-[474px]" />
      </div>
      <Blocks />
      <div className="absolute top-[7296px] left-[180px] w-[717px] h-9 overflow-hidden text-11xl">
        <div className="absolute top-[0px] left-[0px] font-semibold">
          Concept
        </div>
        <div className="absolute top-[4px] left-[330px] text-5xl text-gray-100">
          Award wining concepts and ideas.
        </div>
      </div>
      <div className="absolute top-[7417px] left-[180px] w-[948px] h-9 overflow-hidden text-gray-100">
        <div className="absolute top-[3px] left-[330px]">
          Strategic master plans and business concept strategy.
        </div>
        <div className="absolute top-[0px] left-[0px] text-11xl font-semibold text-black">
          Graphic Design
        </div>
      </div>
      <div className="absolute top-[7538px] left-[180px] w-[885px] h-9 overflow-hidden text-gray-100">
        <div className="absolute top-[4px] left-[330px]">
          High quality products that offer an all-in solution.
        </div>
        <div className="absolute top-[0px] left-[0px] text-11xl font-semibold text-black">
          Strategy
        </div>
      </div>
      <img
        className="absolute top-[7837px] left-[185px] w-[1070px] h-[100px] overflow-hidden"
        alt=""
        src="/frame.svg"
      />
      <div className="absolute top-[8449px] left-[70px] w-[159px] h-9 overflow-hidden text-11xl">
        <b className="absolute top-[0px] left-[0px]">MK</b>
        <div className="absolute top-[3px] left-[59px] text-xs font-medium text-gray-100">
          <p className="m-0">{`UI/UX Designer &`}</p>
          <p className="m-0">Product Designer</p>
        </div>
      </div>
      <div className="absolute top-[8575px] left-[70px] w-[1286px] h-[84px] overflow-hidden text-4xl text-gray-100">
        <div className="absolute top-[0px] left-[0px] font-medium">
          <p className="m-0">MK is an award UI/UX designer</p>
          <p className="m-0">and Product designer based in</p>
          <p className="m-0">Kathmandu, Nepal.</p>
        </div>
        <div className="absolute top-[0px] left-[1092px] font-medium">
          address
        </div>
        <div className="absolute top-[50px] left-[1092px] font-medium">
          contact@mk.com
        </div>
      </div>
      <Footer />
      <div className="absolute top-[1019px] left-[70px] w-[1300px] h-6 overflow-hidden text-xl">
        <div className="absolute top-[0px] left-[0px]">Our Philosophy</div>
      </div>
      <div className="absolute top-[7066px] left-[70px] w-[1300px] h-[150px] overflow-hidden text-105xl">
        <div className="absolute top-[0px] left-[0px] font-semibold">
          Our Services
        </div>
      </div>
      <div className="absolute top-[8088px] left-[441px] text-105xl font-semibold">
        Let’s Talk
      </div>
      <div className="absolute top-[8037px] left-[609px] text-xl text-gray-100">
        Want to start a project?
      </div>
      <div className="absolute top-[7735px] left-[512px] w-[416px] h-[29px] overflow-hidden">
        <div className="absolute top-[0px] left-[1px] font-medium">
          Teams and companies we work with
        </div>
      </div>
      <div className="absolute top-[7346.5px] left-[-0.5px] box-border w-[1441px] h-px border-t-[1px] border-solid border-gainsboro" />
    </div>
  );
};

export default Home;
