import type { NextPage } from "next";

const Frame: NextPage = () => {
  return <div className="relative bg-white w-full h-[100px] overflow-hidden" />;
};

export default Frame;
