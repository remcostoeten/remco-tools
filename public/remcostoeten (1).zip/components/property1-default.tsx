import type { NextPage } from "next";
import { useMemo, type CSSProperties } from "react";

type Property1DefaultType = {
  /** Style props */
  property1DefaultPosition?: CSSProperties["position"];
  property1DefaultTop?: CSSProperties["top"];
  property1DefaultLeft?: CSSProperties["left"];
};

const Property1Default: NextPage<Property1DefaultType> = ({
  property1DefaultPosition,
  property1DefaultTop,
  property1DefaultLeft,
}) => {
  const property1DefaultStyle: CSSProperties = useMemo(() => {
    return {
      position: property1DefaultPosition,
      top: property1DefaultTop,
      left: property1DefaultLeft,
    };
  }, [property1DefaultPosition, property1DefaultTop, property1DefaultLeft]);

  return (
    <div
      className="w-[1440px] h-[174px] overflow-hidden text-left text-105xl text-black font-inter"
      style={property1DefaultStyle}
    >
      <div className="absolute top-[0px] left-[-1195px] w-[2897px] h-[174px]">
        <b className="absolute top-[0px] left-[1004px] leading-[140.52%]">
          Featured Work
        </b>
        <b className="absolute top-[0px] left-[2008px] leading-[140.52%]">
          Featured Work
        </b>
        <b className="absolute top-[0px] left-[0px] leading-[140.52%]">
          Featured Work
        </b>
        <div className="absolute top-[80px] left-[939px] rounded-[50%] bg-black w-[15px] h-[15px]" />
        <div className="absolute top-[80px] left-[1943px] rounded-[50%] bg-black w-[15px] h-[15px]" />
      </div>
    </div>
  );
};

export default Property1Default;
