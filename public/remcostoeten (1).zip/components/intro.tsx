import type { NextPage } from "next";

const Intro: NextPage = () => {
  return (
    <div className="absolute top-[241px] left-[180px] w-[1050px] h-[363px] overflow-hidden text-left text-105xl text-black font-inter">
      <b className="absolute top-[63px] left-[0px]">
        <p className="m-0">We’re creative</p>
        <p className="m-0">digital studio.</p>
      </b>
      <div className="absolute top-[20px] left-[0px] text-xl font-medium text-gray-200">
        Hello people!
      </div>
      <div className="absolute top-[0px] left-[925px] w-[125px] h-[125px] overflow-hidden text-xs">
        <div className="absolute top-[4px] left-[4px] w-[116px] h-[116px]">
          <div className="absolute top-[1.23px] left-[46.72px] font-medium inline-block w-[6.43px] h-[24.11px] [transform:_rotate(-8.59deg)] [transform-origin:0_0]">
            .
          </div>
          <div className="absolute top-[3.26px] left-[39.23px] font-medium inline-block h-[24.11px] [transform:_rotate(-16.45deg)] [transform-origin:0_0]">{` `}</div>
          <div className="absolute top-[10.12px] left-[25.12px] font-medium inline-block w-[12.86px] h-[24.11px] [transform:_rotate(-28.84deg)] [transform-origin:0_0]">
            n
          </div>
          <div className="absolute top-[26.35px] left-[9px] font-medium inline-block w-[16.07px] h-[24.11px] [transform:_rotate(-49.33deg)] [transform-origin:0_0]">
            w
          </div>
          <div className="absolute top-[43.59px] left-[1.74px] font-medium inline-block w-[12.86px] h-[24.11px] [transform:_rotate(-69.88deg)] [transform-origin:0_0]">
            o
          </div>
          <div className="absolute top-[61.59px] left-[0px] font-medium inline-block w-[12.86px] h-[24.1px] [transform:_rotate(-87.54deg)] [transform-origin:0_0]">
            d
          </div>
          <div className="absolute top-[70.94px] left-[1.6px] font-medium inline-block h-[24.11px] [transform:_rotate(-100.33deg)] [transform-origin:0_0]">{` `}</div>
          <div className="absolute top-[77.93px] left-[3.67px] font-medium inline-block w-[4.82px] h-[24.11px] [transform:_rotate(-107.69deg)] [transform-origin:0_0]">
            l
          </div>
          <div className="absolute top-[84.53px] left-[6.56px] font-medium inline-block w-[4.82px] h-[24.11px] [transform:_rotate(-114.83deg)] [transform-origin:0_0]">
            l
          </div>
          <div className="absolute top-[97.56px] left-[15.39px] font-medium inline-block w-[12.86px] h-[24.11px] [transform:_rotate(-127.05deg)] [transform-origin:0_0]">
            o
          </div>
          <div className="absolute top-[105.49px] left-[24.72px] font-medium inline-block w-[8.04px] h-[24.11px] [transform:_rotate(-141.22deg)] [transform-origin:0_0]">
            r
          </div>
          <div className="absolute top-[112.78px] left-[38.48px] font-medium inline-block w-[11.25px] h-[24.11px] [transform:_rotate(-154.9deg)] [transform-origin:0_0]">
            c
          </div>
          <div className="absolute top-[116px] left-[53.88px] font-medium inline-block w-[11.25px] h-[24.11px] [transform:_rotate(-170.76deg)] [transform-origin:0_0]">
            s
          </div>
          <div className="absolute top-[115.77px] left-[62.9px] font-medium inline-block h-[24.11px] [transform:_rotate(177.73deg)] [transform-origin:0_0]">{` `}</div>
          <div className="absolute top-[114.54px] left-[70.91px] font-medium inline-block w-[6.43px] h-[24.11px] [transform:_rotate(169.88deg)] [transform-origin:0_0]">
            .
          </div>
          <div className="absolute top-[112.31px] left-[78.34px] font-medium inline-block h-[24.11px] [transform:_rotate(162.02deg)] [transform-origin:0_0]">{` `}</div>
          <div className="absolute top-[105.07px] left-[92.27px] font-medium inline-block w-[12.86px] h-[24.11px] [transform:_rotate(149.63deg)] [transform-origin:0_0]">
            n
          </div>
          <div className="absolute top-[88.42px] left-[107.94px] font-medium inline-block w-[16.07px] h-[24.11px] [transform:_rotate(129.14deg)] [transform-origin:0_0]">
            w
          </div>
          <div className="absolute top-[70.99px] left-[114.74px] font-medium inline-block w-[12.86px] h-[24.11px] [transform:_rotate(108.58deg)] [transform-origin:0_0]">
            o
          </div>
          <div className="absolute top-[52.95px] left-[116px] font-medium inline-block w-[12.86px] h-[24.1px] [transform:_rotate(90.93deg)] [transform-origin:0_0]">
            d
          </div>
          <div className="absolute top-[43.64px] left-[114.15px] font-medium inline-block h-[24.11px] [transform:_rotate(78.14deg)] [transform-origin:0_0]">{` `}</div>
          <div className="absolute top-[36.71px] left-[111.89px] font-medium inline-block w-[4.82px] h-[24.11px] [transform:_rotate(70.78deg)] [transform-origin:0_0]">
            l
          </div>
          <div className="absolute top-[30.19px] left-[108.82px] font-medium inline-block w-[4.82px] h-[24.11px] [transform:_rotate(63.64deg)] [transform-origin:0_0]">
            l
          </div>
          <div className="absolute top-[17.4px] left-[99.65px] font-medium inline-block w-[12.86px] h-[24.11px] [transform:_rotate(51.42deg)] [transform-origin:0_0]">
            o
          </div>
          <div className="absolute top-[9.72px] left-[90.11px] font-medium inline-block w-[8.04px] h-[24.11px] [transform:_rotate(37.24deg)] [transform-origin:0_0]">
            r
          </div>
          <div className="absolute top-[2.81px] left-[76.16px] font-medium inline-block w-[11.25px] h-[24.11px] [transform:_rotate(23.57deg)] [transform-origin:0_0]">
            c
          </div>
          <div className="absolute top-[0px] left-[60.69px] font-medium inline-block w-[11.25px] h-[24.11px] [transform:_rotate(7.7deg)] [transform-origin:0_0]">
            s
          </div>
        </div>
      </div>
      <div className="absolute top-[23px] left-[963px] w-[49px] h-20 overflow-hidden">
        <div className="absolute top-[17px] left-[11px] w-[26px] h-[46px]">
          <div className="absolute top-[0px] left-[0px] rounded-xl box-border w-[26px] h-[46px] border-[3px] border-solid border-black" />
          <div className="absolute top-[27px] left-[7px] rounded-[50%] bg-black w-3 h-3" />
        </div>
      </div>
    </div>
  );
};

export default Intro;
