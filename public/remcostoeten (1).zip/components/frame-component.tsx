import type { NextPage } from "next";
import { useMemo, type CSSProperties } from "react";

type FrameComponentType = {
  sectionTitle?: string;

  /** Style props */
  frameDivBorder?: CSSProperties["border"];
  frameDivPosition?: CSSProperties["position"];
  frameDivTop?: CSSProperties["top"];
  frameDivLeft?: CSSProperties["left"];
  meetTheTeamColor?: CSSProperties["color"];
};

const FrameComponent: NextPage<FrameComponentType> = ({
  sectionTitle,
  frameDivBorder,
  frameDivPosition,
  frameDivTop,
  frameDivLeft,
  meetTheTeamColor,
}) => {
  const frameDivStyle: CSSProperties = useMemo(() => {
    return {
      border: frameDivBorder,
      position: frameDivPosition,
      top: frameDivTop,
      left: frameDivLeft,
    };
  }, [frameDivBorder, frameDivPosition, frameDivTop, frameDivLeft]);

  const meetTheTeamStyle: CSSProperties = useMemo(() => {
    return {
      color: meetTheTeamColor,
    };
  }, [meetTheTeamColor]);

  return (
    <div
      className="rounded-10xl-5 flex flex-row py-[18px] px-[26px] items-center justify-center text-left text-base text-black font-inter border-[2px] border-solid border-black"
      style={frameDivStyle}
    >
      <div
        className="relative leading-[140.52%] uppercase"
        style={meetTheTeamStyle}
      >
        {sectionTitle}
      </div>
    </div>
  );
};

export default FrameComponent;
