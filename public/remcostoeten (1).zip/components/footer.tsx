import type { NextPage } from "next";

const Footer: NextPage = () => {
  return (
    <div className="absolute top-[8675px] left-[70px] w-[1300px] h-16 overflow-hidden text-left text-4xl text-gray-100 font-inter">
      <div className="absolute top-[0px] left-[1092px] font-medium">
        +977-9876543210
      </div>
      <img
        className="absolute top-[14px] left-[300px] w-[50px] h-[50px]"
        alt=""
        src="/group-19.svg"
      />
      <img
        className="absolute top-[14px] left-[0px] w-[50px] h-[50px]"
        alt=""
        src="/group-8.svg"
      />
      <img
        className="absolute top-[14px] left-[60px] w-[50px] h-[50px]"
        alt=""
        src="/group-9.svg"
      />
      <img
        className="absolute top-[14px] left-[120px] w-[50px] h-[50px]"
        alt=""
        src="/group-16.svg"
      />
      <img
        className="absolute top-[14px] left-[180px] w-[50px] h-[50px]"
        alt=""
        src="/group-11.svg"
      />
      <img
        className="absolute top-[14px] left-[240px] w-[50px] h-[50px]"
        alt=""
        src="/group-18.svg"
      />
    </div>
  );
};

export default Footer;
