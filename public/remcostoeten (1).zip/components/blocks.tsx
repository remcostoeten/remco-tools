import type { NextPage } from "next";

const Blocks: NextPage = () => {
  return (
    <div className="absolute top-[2076px] left-[0px] w-[1440px] h-[4866px] overflow-hidden text-left text-61xl text-white font-inter">
      <div className="absolute top-[0px] left-[0px] bg-lightblue w-[1440px] h-[811px]" />
      <div className="absolute top-[811px] left-[0px] bg-skyblue w-[1440px] h-[811px]" />
      <div className="absolute top-[1622px] left-[0px] bg-lightblue w-[1440px] h-[811px]" />
      <div className="absolute top-[2433px] left-[0px] bg-skyblue w-[1440px] h-[811px]" />
      <div className="absolute top-[3244px] left-[0px] bg-lightblue w-[1440px] h-[811px]" />
      <div className="absolute top-[4055px] left-[0px] bg-skyblue w-[1440px] h-[811px]" />
      <div className="absolute top-[363px] left-[557px] font-semibold">
        Fashion
      </div>
      <div className="absolute top-[1174px] left-[532px] font-semibold">
        Magazine
      </div>
      <div className="absolute top-[1985px] left-[546px] font-semibold">
        Graphics
      </div>
      <div className="absolute top-[2796px] left-[585px] font-semibold">
        Motion
      </div>
      <div className="absolute top-[3607px] left-[557px] font-semibold">
        Products
      </div>
      <div className="absolute top-[4418px] left-[634px] font-semibold">
        Blog
      </div>
      <div className="absolute top-[467px] left-[556px] box-border w-[306px] h-0.5 border-t-[2px] border-solid border-white" />
      <div className="absolute top-[1278px] left-[531px] box-border w-[379px] h-0.5 border-t-[2px] border-solid border-white" />
      <div className="absolute top-[2089px] left-[545px] box-border w-[350px] h-0.5 border-t-[2px] border-solid border-white" />
      <div className="absolute top-[2900px] left-[584px] box-border w-[272px] h-0.5 border-t-[2px] border-solid border-white" />
      <div className="absolute top-[3711px] left-[556px] box-border w-[351px] h-0.5 border-t-[2px] border-solid border-white" />
      <div className="absolute top-[4522px] left-[633px] box-border w-[175px] h-0.5 border-t-[2px] border-solid border-white" />
      <div className="absolute top-[344px] left-[846px] text-xl">1/6</div>
      <div className="absolute top-[1155px] left-[894px] text-xl">2/6</div>
      <div className="absolute top-[1966px] left-[877px] text-xl">3/6</div>
      <div className="absolute top-[2777px] left-[838px] text-xl">4/6</div>
      <div className="absolute top-[3588px] left-[890px] text-xl">5/6</div>
      <div className="absolute top-[4399px] left-[790px] text-xl">6/6</div>
    </div>
  );
};

export default Blocks;
