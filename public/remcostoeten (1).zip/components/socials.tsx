import type { NextPage } from "next";
import { useCallback } from "react";

const Socials: NextPage = () => {
  const onGroupIcon1Click = useCallback(() => {
    window.open(" https://instagramcom/yowremco");
  }, []);

  const onGroupIcon3Click = useCallback(() => {
    window.open("https://linkedin.com/remcostoeten");
  }, []);

  return (
    <div className="absolute top-[774px] left-[545px] w-[350px] h-[51px] overflow-hidden">
      <img
        className="absolute top-[1px] left-[300px] w-[50px] h-[50px]"
        alt=""
        src="/group-19.svg"
      />
      <img
        className="absolute top-[0px] left-[0px] w-[50px] h-[50px] cursor-pointer"
        alt=""
        src="/group-8.svg"
        onClick={onGroupIcon1Click}
      />
      <img
        className="absolute top-[0px] left-[60px] w-[50px] h-[50px]"
        alt=""
        src="/group-9.svg"
      />
      <div className="absolute top-[0px] left-[120px] w-[50px] h-[50px]">
        <img
          className="absolute top-[13px] left-[13px] w-6 h-6 cursor-pointer"
          alt=""
          src="/group-4.svg"
          onClick={onGroupIcon3Click}
        />
        <div className="absolute top-[0px] left-[0px] rounded-[50%] box-border w-[50px] h-[50px] border-[1px] border-solid border-gainsboro" />
      </div>
      <img
        className="absolute top-[0px] left-[180px] w-[50px] h-[50px]"
        alt=""
        src="/group-11.svg"
      />
      <img
        className="absolute top-[0px] left-[240px] w-[50px] h-[50px]"
        alt=""
        src="/group-12.svg"
      />
    </div>
  );
};

export default Socials;
